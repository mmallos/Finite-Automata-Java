import static org.junit.Assert.*;

import org.junit.Test;

public class DFAExampleTest {

	@Test
	public void testAcceptStrings() {
		assertTrue(DFA.accepts("00"));
		assertTrue(DFA.accepts("010"));
		assertTrue(DFA.accepts("000000"));
		assertTrue(DFA.accepts("00000010000"));
		assertTrue(DFA.accepts("100000000000"));
		assertTrue(DFA.accepts("00000000000001"));
	}

	@Test
	public void testRejectStrings() {
		assertFalse(DFA.accepts(""));
		assertFalse(DFA.accepts("1"));
		assertFalse(DFA.accepts("0"));
		assertFalse(DFA.accepts("101"));
		assertFalse(DFA.accepts("1111"));
		assertFalse(DFA.accepts("100001000010001"));
	}

}
