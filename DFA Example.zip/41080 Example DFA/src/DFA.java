
public class DFA {

	private enum State {
		ZEROZERO, ZEROONE, ONEZERO, ONEONE, ENOUGHZERO, ENOUGHONE, TOOMANY
	};

	public static boolean accepts(String input) {

		State state = State.ZEROZERO;

		for (int i = 0; i < input.length(); i++) {

			if (input.charAt(i) == '1') {

				switch (state) {
				case ZEROZERO:
					state = State.ZEROONE;
					break;
				case ZEROONE:
					state = State.TOOMANY;
					break;
				case ONEZERO:
					state = State.ONEONE;
					break;
				case ONEONE:
					state = State.TOOMANY;
					break;
				case ENOUGHZERO:
					state = State.ENOUGHONE;
					break;
				case ENOUGHONE:
					state = State.TOOMANY;
					break;
				case TOOMANY:
					state = State.TOOMANY;
					break;
				}

			} else if (input.charAt(i) == '0') {

				switch (state) {
				case ZEROZERO:
					state = State.ONEZERO;
					break;
				case ZEROONE:
					state = State.ONEONE;
					break;
				case ONEZERO:
					state = State.ENOUGHZERO;
					break;
				case ONEONE:
					state = State.ENOUGHONE;
					break;
				case ENOUGHZERO:
					state = State.ENOUGHZERO;
					break;
				case ENOUGHONE:
					state = State.ENOUGHONE;
					break;
				case TOOMANY:
					state = State.TOOMANY;
					break;
				}
			}

		}

		if (state == State.ENOUGHZERO || state == State.ENOUGHONE) return true;
		
		return false;
	}

}
